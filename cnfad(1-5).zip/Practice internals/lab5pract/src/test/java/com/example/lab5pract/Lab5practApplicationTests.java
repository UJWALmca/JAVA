package com.example.lab5pract;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab5practApplicationTests {

	@Test
	void contextLoads() {
	}

}
