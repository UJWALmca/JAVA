package com.example.lab02pract;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab02practApplicationTests {

	@Test
	void contextLoads() {
	}

}
