package com.example.lab02pract;

public class College {
int Cid;
String CName,CAddress;
public int getCid() {
	return Cid;
}
public void setCid(int cid) {
	Cid = cid;
}
public String getCName() {
	return CName;
}
public void setCName(String cName) {
	CName = cName;
}
public String getCAddress() {
	return CAddress;
}
public void setCAddress(String cAddress) {
	CAddress = cAddress;
}

}
