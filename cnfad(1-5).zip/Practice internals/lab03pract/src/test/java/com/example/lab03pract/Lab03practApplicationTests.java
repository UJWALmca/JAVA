package com.example.lab03pract;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab03practApplicationTests {

	@Test
	void contextLoads() {
	}

}
