package com.example.lab03pract;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab03practApplication {

	public static void main(String[] args) {
		SpringApplication.run(Lab03practApplication.class, args);
	}

}
