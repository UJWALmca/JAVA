package com.example.lab01pract;

public class Ticket {
int TickId,TickPrice,TSeatNo;

public int getTickId() {
	return TickId;
}

public void setTickId(int tickId) {
	TickId = tickId;
}

public int getTickPrice() {
	return TickPrice;
}

public void setTickPrice(int tickPrice) {
	TickPrice = tickPrice;
}

public int getTSeatNo() {
	return TSeatNo;
}

public void setTSeatNo(int tSeatNo) {
	TSeatNo = tSeatNo;
}



}
