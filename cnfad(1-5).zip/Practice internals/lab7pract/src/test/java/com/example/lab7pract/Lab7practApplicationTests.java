package com.example.lab7pract;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab7practApplicationTests {

	@Test
	void contextLoads() {
	}

}
