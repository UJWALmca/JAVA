package com.example.lab7pract;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class CustomerService {
@Autowired
CustomerRepository customerRepository;

public void addCustomer(long id,String firstName,String lastName) {
	Customer customer = new Customer();
	customer.setId(id);
	customer.setFirstName(firstName);
	customer.setLastName(lastName);
	customerRepository.save(customer);
	System.out.println("Customer record added succesfully");
}

public void updateCustomer(long id,String ufname,String ulname) {
	Customer customer = customerRepository.findById(id).orElse(null); 
	//		Customer customer = customerRepository.findById(id).orElse(null);
	customer.setFirstName(ufname);
	customer.setLastName(ulname);
	System.out.println("Customer record updated succesfully");
}

	public List<Customer> getAllCustomer() {
		return customerRepository.findAll();
	}
	
	public void deleteCustomer(long id) {
		Customer customer = customerRepository.findById(id).orElse(null); 
		customerRepository.delete(customer);
		System.out.println("Customer record deleted succesfully");
	}
}
